import 'dart:io';
import 'package:flutter/material.dart';

import '../../models/pet.dart';
import 'profile_view_page.dart';
import 'profile_edit_page.dart';

class PetListPage extends StatefulWidget {
  final List<Pet> pets;
  final Future<void> Function(Pet pet) onAdd;
  final Future<void> Function(int index, Pet pet) onUpdate;
  final Future<void> Function(int index) onDelete;

  const PetListPage({
    super.key,
    required this.pets,
    required this.onAdd,
    required this.onUpdate,
    required this.onDelete,
  });

  @override
  State<PetListPage> createState() => _PetListPageState();
}

class _PetListPageState extends State<PetListPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () async {
          final Pet? newPet = await Navigator.push<Pet>(
            context,
            MaterialPageRoute(
              builder: (_) => const ProfileEditPage(),
            ),
          );

          if (newPet != null) {
            await widget.onAdd(newPet);
            setState(() {});
          }
        },
      ),
      body: widget.pets.isEmpty
          ? const Center(
        child: Text(
          "Henüz hayvan eklenmedi 🐾",
          style: TextStyle(fontSize: 16),
        ),
      )
          : ListView.builder(
        itemCount: widget.pets.length,
        itemBuilder: (context, index) {
          final pet = widget.pets[index];

          return Card(
            margin:
            const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: ListTile(
              leading: _buildPetAvatar(pet),
              title: Text(
                pet.name,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text("${pet.type} • ${pet.breed}"),
              onTap: () async {
                final result = await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ProfileViewPage(pet: pet),
                  ),
                );

                if (result == "delete") {
                  await widget.onDelete(index);
                  setState(() {});
                } else if (result is Pet) {
                  await widget.onUpdate(index, result);
                  setState(() {});
                }
              },
            ),
          );
        },
      ),
    );
  }

  /// 🖼 FOTO / AVATAR KARARI
  Widget _buildPetAvatar(Pet pet) {
     if (pet.imagePath != null && pet.imagePath!.isNotEmpty) {
       // 1. Preset Avatar (Emoji)
       if (pet.imagePath!.startsWith("avatar:")) {
         final emoji = pet.imagePath!.replaceAll("avatar:", "");
         return CircleAvatar(
           radius: 28,
           backgroundColor: Colors.orange.shade100,
           child: Text(emoji, style: const TextStyle(fontSize: 24)),
         );
       } 
       
       // 2. Dosya Yolu
       try {
         final file = File(pet.imagePath!);
         if (file.existsSync()) {
           return CircleAvatar(
             radius: 28,
             backgroundColor: Colors.grey.shade300,
             backgroundImage: FileImage(file),
           );
         }
       } catch (e) { }
     }

     // 3. Varsayılan Asset
     String asset = 'assets/images/avatars/cat.png';
     if (pet.type == "Köpek") asset = 'assets/images/avatars/dog.png';

     return CircleAvatar(
       radius: 28,
       backgroundColor: Colors.grey.shade300,
       backgroundImage: AssetImage(asset),
     );
  }
}
