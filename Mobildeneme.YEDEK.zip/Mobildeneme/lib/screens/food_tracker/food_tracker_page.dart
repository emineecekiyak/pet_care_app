import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:mobil1/models/food_entry.dart';
import 'package:mobil1/models/pet.dart';
import 'package:mobil1/services/notification_service.dart';

class FoodTrackerPage extends StatefulWidget {
  final List<Pet> pets;

  const FoodTrackerPage({
    super.key,
    required this.pets,
  });

  @override
  State<FoodTrackerPage> createState() => _FoodTrackerPageState();
}

class _FoodTrackerPageState extends State<FoodTrackerPage> {
  final List<FoodEntry> _entries = [];



  Future<void> _loadEntries() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('food_entries');
    if (raw == null) return;

    final List decoded = jsonDecode(raw);
    setState(() {
      _entries
        ..clear()
        ..addAll(
          decoded.map((e) => FoodEntry.fromJson(e as Map<String, dynamic>)),
        );
    });
  }

  Future<void> _saveEntries() async {
    final prefs = await SharedPreferences.getInstance();
    final data =
        jsonEncode(_entries.map((e) => e.toJson()).toList(growable: false));
    await prefs.setString('food_entries', data);
  }

  // 🧮 Ağırlık string'ini (örn: "4.5 kg", "4,5") double'a çevirir
  double _parseWeight(String weightStr) {
    if (weightStr.isEmpty) return 0.0;
    // Harf vs temizle, sadece sayı ve nokta/virgül kalsın
    String clean = weightStr.replaceAll(RegExp(r'[^0-9.,]'), '');
    clean = clean.replaceAll(',', '.');
    return double.tryParse(clean) ?? 0.0;
  }

  // 🦴 Bazal Günlük İhtiyaç (Kuru Mama cinsinden gram)
  double _calculateBaseDailyNeeds(Pet pet) {
    double weight = _parseWeight(pet.weight);
    if (weight <= 0) return 0;
    
    final isPuppy = pet.age < 1;
    double base = 0.0;

    if (pet.type.toLowerCase().contains("kedi")) {
       base = isPuppy ? weight * 30 : weight * 15;
    } else {
       base = isPuppy ? weight * 40 : weight * 20;
    }
    return base;
  }

  // 🥣 Gösterilecek hedeflenen miktar
  int _calculateRecommendedAmount(Pet pet, String foodType) {
    double base = _calculateBaseDailyNeeds(pet);
    
    if (foodType == "Yaş Mama") {
      return (base * 2.5).round();
    } else if (foodType == "Ödül Maması") {
      return (base * 1.0).round(); // Kuru mama ile aynı varsayalım
    }
    return base.round();
  }

  // 📅 Bugün tüketilen toplam miktar (Kuru Mama Bazında)
  double _calculateConsumedTodayInBaseUnits(int petId) {
    final now = DateTime.now();
    return _entries
        .where((e) =>
            e.petId == petId &&
            e.time.year == now.year &&
            e.time.month == now.month &&
            e.time.day == now.day)
        .fold(0.0, (sum, e) {
          double entryBase = 0.0;
          if (e.foodType == "Yaş Mama") {
            entryBase = e.amountGrams / 2.5; 
          } else if (e.foodType == "Ödül Maması") {
             entryBase = e.amountGrams / 1.0; 
          } else {
             entryBase = e.amountGrams.toDouble(); // Kuru Mama
          }
          return sum + entryBase;
        });
  }

  Future<void> _clearToday() async {
     final now = DateTime.now();
     setState(() {
       _entries.removeWhere((e) => 
          e.time.year == now.year && 
          e.time.month == now.month && 
          e.time.day == now.day
       );
     });
     await _saveEntries();
     ScaffoldMessenger.of(context).showSnackBar(
       const SnackBar(content: Text("Bugünkü veriler temizlendi.")),
     );
  }

  Future<void> _openAddDialog() async {
    // Varsayılan
    final amountCtrl = TextEditingController();
    String selectedFoodType = "Kuru Mama";
    final List<String> foodTypes = ["Kuru Mama", "Yaş Mama", "Ödül Maması"];

    if (widget.pets.isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Önce en az bir hayvan eklemelisin.")),
      );
      return;
    }

    // İlk açılışta seçili değerler
    Pet selectedPet = widget.pets.first;
    
    // İlk hesaplama
    int calc = _calculateRecommendedAmount(selectedPet, selectedFoodType);
    if (calc > 0) {
      amountCtrl.text = calc.toString();
    }

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) {
        return Padding(
          padding: EdgeInsets.only(
            left: 16,
            right: 16,
            top: 16,
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 16,
          ),
          child: StatefulBuilder(
            builder: (context, setModalState) {
              
              void updateAmount() {
                final val = _calculateRecommendedAmount(selectedPet, selectedFoodType);
                setModalState(() {
                   amountCtrl.text = val > 0 ? val.toString() : "";
                });
              }

              return Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Mama Kaydı Ekle",
                    style: Theme.of(ctx)
                        .textTheme
                        .titleMedium
                        ?.copyWith(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<Pet>(
                    value: selectedPet,
                    decoration: const InputDecoration(
                      labelText: "Hayvan",
                      border: OutlineInputBorder(),
                    ),
                    items: widget.pets
                        .map(
                          (p) => DropdownMenuItem(
                            value: p,
                            child: Text(p.name),
                          ),
                        )
                        .toList(),
                    onChanged: (value) {
                      if (value == null) return;
                      selectedPet = value;
                      updateAmount(); // Hayvan değişince hesapla
                      setModalState(() {});
                    },
                  ),
                  const SizedBox(height: 12),
                  
                  // Mama Türü Combobox
                  DropdownButtonFormField<String>(
                    value: selectedFoodType,
                    decoration: const InputDecoration(
                      labelText: "Mama Türü",
                      border: OutlineInputBorder(),
                    ),
                    items: foodTypes.map((t) {
                      return DropdownMenuItem(value: t, child: Text(t));
                    }).toList(),
                    onChanged: (val) {
                      if (val == null) return;
                      selectedFoodType = val;
                      updateAmount(); // Mama türü değişince hesapla
                      setModalState(() {}); 
                    },
                  ),

                  const SizedBox(height: 12),
                  TextField(
                    controller: amountCtrl,
                    decoration: const InputDecoration(
                      labelText: "Miktar (gram)",
                      border: OutlineInputBorder(),
                      helperText: "Otomatik hesaplandı, değiştirebilirsiniz.",
                    ),
                    keyboardType: TextInputType.number,
                    textInputAction: TextInputAction.done,
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        final amount = int.tryParse(amountCtrl.text) ?? 0;
                        if (amount <= 0) {
                          Navigator.pop(ctx);
                          return;
                        }
                        
                        // 🔍 Stok Kontrolü
                        int currentStock = 0;
                        final isCat = selectedPet.type.toLowerCase().contains("kedi");
                        
                        if (isCat) {
                          if (selectedFoodType == "Kuru Mama") currentStock = _catDryStock;
                          if (selectedFoodType == "Yaş Mama") currentStock = _catWetStock;
                          if (selectedFoodType == "Ödül Maması") currentStock = _catTreatStock;
                        } else {
                          if (selectedFoodType == "Kuru Mama") currentStock = _dogDryStock;
                          if (selectedFoodType == "Yaş Mama") currentStock = _dogWetStock;
                          if (selectedFoodType == "Ödül Maması") currentStock = _dogTreatStock;
                        }

                        if (currentStock < amount) {
                          showDialog(
                            context: ctx, // BottomSheet context'ini kullan
                            builder: (dialogCtx) {
                              return AlertDialog(
                                title: const Text("Yetersiz Stok ⚠️", style: TextStyle(color: Colors.red)),
                                content: Text("Depoda sadece $currentStock gr $selectedFoodType var.\nLütfen önce stok ekleyin veya miktarı azaltın."),
                                actions: [
                                  TextButton(
                                    onPressed: () => Navigator.pop(dialogCtx),
                                    child: const Text("Tamam"),
                                  ),
                                ],
                              );
                            }
                          );
                          return; // İşlemi iptal et
                        }
                        
                        // 📉 Stoktan Düş (Granular)
                        // Kedi/Köpek + Mama Türü
                        setState(() {
                          final isCat = selectedPet.type.toLowerCase().contains("kedi");
                          if (isCat) {
                             if (selectedFoodType == "Kuru Mama") _catDryStock = (_catDryStock - amount) < 0 ? 0 : _catDryStock - amount;
                             if (selectedFoodType == "Yaş Mama") _catWetStock = (_catWetStock - amount) < 0 ? 0 : _catWetStock - amount;
                             if (selectedFoodType == "Ödül Maması") _catTreatStock = (_catTreatStock - amount) < 0 ? 0 : _catTreatStock - amount;
                          } else {
                             if (selectedFoodType == "Kuru Mama") _dogDryStock = (_dogDryStock - amount) < 0 ? 0 : _dogDryStock - amount;
                             if (selectedFoodType == "Yaş Mama") _dogWetStock = (_dogWetStock - amount) < 0 ? 0 : _dogWetStock - amount;
                             if (selectedFoodType == "Ödül Maması") _dogTreatStock = (_dogTreatStock - amount) < 0 ? 0 : _dogTreatStock - amount;
                          }
                        });
                        _saveStock();

                        final entry = FoodEntry(
                          petId: selectedPet.id,
                          petName: selectedPet.name,
                          foodType: selectedFoodType,
                          amountGrams: amount,
                          time: DateTime.now(),
                        );

                        setState(() {
                          _entries.insert(0, entry);
                        });
                        _saveEntries();
                        _checkStockLevels();
                        Navigator.pop(ctx);
                      },
                      child: const Text("Kaydet"),
                    ),
                  ),
                ],
              );
            },
          ),
        );
      },
    );
  }

  String _formatTime(DateTime time) {
    final date =
        "${time.day.toString().padLeft(2, '0')}.${time.month.toString().padLeft(2, '0')}.${time.year}";
    final hour =
        "${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}";
    return "$date • $hour";
  }

  String _dailyRecFoodType = "Kuru Mama";

  Widget _buildDailyRecommendationSection() {
    if (widget.pets.isEmpty) return const SizedBox.shrink();

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.orange.shade400, Colors.orange.shade700],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: const BorderRadius.vertical(bottom: Radius.circular(24)),
        boxShadow: [
          BoxShadow(
            color: Colors.orange.withOpacity(0.3),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: SafeArea(
        bottom: false,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  "Günlük Ne Kadar Yemeli? 🍽️",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.cleaning_services_rounded, color: Colors.white70),
                  onPressed: _clearToday,
                  tooltip: "Bugünü Sıfırla",
                ),
              ],
            ),
            const SizedBox(height: 12),
            // Food Type Toggles
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: ["Kuru Mama", "Yaş Mama", "Ödül Maması"].map((type) {
                  final isSelected = _dailyRecFoodType == type;
                  return Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ChoiceChip(
                      label: Text(type),
                      selected: isSelected,
                      onSelected: (val) {
                        if (val) {
                          setState(() {
                            _dailyRecFoodType = type;
                          });
                        }
                      },
                      selectedColor: Colors.white,
                      backgroundColor: Colors.orange.shade800,
                      labelStyle: TextStyle(
                        color: isSelected ? Colors.orange.shade900 : Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
                    ),
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 16),
            // Pet Cards
            SizedBox(
              height: 140, // Yükseklik arttırıldı (Detay göstermek için)
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: widget.pets.length,
                itemBuilder: (context, index) {
                  final pet = widget.pets[index];
                  
                  // 1. Bazal Hedef (Kuru Mama cinsinden)
                  double baseTarget = _calculateBaseDailyNeeds(pet);
                  
                  // 2. Tüketilen (Kuru Mama cinsinden toplam)
                  // ID yoksa -1 ver (Hesaplamayı durdurur)
                  double baseConsumed = _calculateConsumedTodayInBaseUnits(pet.id ?? -1);
                  
                  // 3. Kalan (Kuru Mama cinsinden)
                  double baseRemaining = (baseTarget - baseConsumed).clamp(0, baseTarget);

                  // 4. Gösterim Çarpanı (Seçili türe çevir)
                  double displayMultiplier = 1.0;
                  if (_dailyRecFoodType == "Yaş Mama") displayMultiplier = 2.5;
                  if (_dailyRecFoodType == "Ödül Maması") displayMultiplier = 1.0;

                  // 5. Ekrana basılacak değerler
                  int displayTarget = (baseTarget * displayMultiplier).round();
                  int displayConsumed = (baseConsumed * displayMultiplier).round();
                  int displayRemaining = (baseRemaining * displayMultiplier).round();
                  
                  // 6. Progress
                  double progress = baseTarget > 0 
                      ? (baseConsumed / baseTarget).clamp(0.0, 1.0) 
                      : 0.0;
                  
                  // Varsayılan Avatar (Fotoğraf yoksa)
                  final isCat = pet.type.toLowerCase().contains("kedi");
                  final defaultAvatar = Text(
                    isCat ? "🐱" : "🐶",
                    style: const TextStyle(fontSize: 28),
                  );
                  
                  return Container(
                    width: 230,
                    margin: const EdgeInsets.only(right: 12),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.white.withOpacity(0.3)),
                    ),
                    child: Row(
                      children: [
                        // Avatar
                        Container(
                          width: 52,
                          height: 52,
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.white,
                          ),
                          child: ClipOval(
                            child: Builder(
                              builder: (context) {
                                // 1. Preset Avatar (Emoji)
                                if (pet.imagePath != null && pet.imagePath!.startsWith("avatar:")) {
                                  final emoji = pet.imagePath!.replaceAll("avatar:", "");
                                  return Center(child: Text(emoji, style: const TextStyle(fontSize: 28)));
                                }

                                // 2. Dosya
                                if (pet.imagePath != null && pet.imagePath!.isNotEmpty) {
                                   return Image.file(
                                    File(pet.imagePath!),
                                    fit: BoxFit.cover,
                                    width: 52,
                                    height: 52,
                                    errorBuilder: (context, error, stackTrace) {
                                      return Center(child: defaultAvatar);
                                    },
                                  );
                                }

                                // 3. Fallback
                                return Center(child: defaultAvatar);
                              },
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        // Info
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                pet.name,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                              const SizedBox(height: 6),
                              // Progress Bar
                              ClipRRect(
                                borderRadius: BorderRadius.circular(4),
                                child: LinearProgressIndicator(
                                  value: progress,
                                  backgroundColor: Colors.white.withOpacity(0.3),
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                      progress >= 1.0 ? Colors.redAccent : Colors.white),
                                  minHeight: 6,
                                ),
                              ),
                              const SizedBox(height: 6),
                              // Text Details: Kalan ve Detay
                              Text(
                                displayRemaining == 0 
                                  ? "Limit Doldu 🛑" 
                                  : "Kalan: ~$displayRemaining gr",
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 13,
                                  fontWeight: FontWeight.w500
                                ),
                              ),
                              Text(
                                // Detaylı gösterim: "Yenen / Hedef"
                                "$displayConsumed / $displayTarget gr",
                                style: TextStyle(
                                  color: Colors.white.withOpacity(0.8),
                                  fontSize: 11,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  // 📦 Stok Değişkenleri (Granular)
  int _catDryStock = 0;   // 🐱 Kuru
  int _catWetStock = 0;   // 🐱 Yaş
  int _catTreatStock = 0; // 🐱 Ödül

  int _dogDryStock = 0;   // 🐶 Kuru
  int _dogWetStock = 0;   // 🐶 Yaş
  int _dogTreatStock = 0; // 🐶 Ödül

  @override
  void initState() {
    super.initState();
    _loadEntries();
    _loadStock();
  }

  Future<void> _checkStockLevels() async {
    const threshold = 160;
    if (_catDryStock > 0 && _catDryStock <= threshold) {
      await NotificationService().showInstantNotification(101, "Azalan Stok: Kedi Kuru Mama 🐱", "Stokta sadece $_catDryStock gr kaldı!");
    }
    if (_catWetStock > 0 && _catWetStock <= threshold) {
      await NotificationService().showInstantNotification(102, "Azalan Stok: Kedi Yaş Mama 🐱", "Stokta sadece $_catWetStock gr kaldı!");
    }
    if (_catTreatStock > 0 && _catTreatStock <= threshold) {
      await NotificationService().showInstantNotification(103, "Azalan Stok: Kedi Ödül Maması 🐱", "Stokta sadece $_catTreatStock gr kaldı!");
    }
    if (_dogDryStock > 0 && _dogDryStock <= threshold) {
      await NotificationService().showInstantNotification(104, "Azalan Stok: Köpek Kuru Mama 🐶", "Stokta sadece $_dogDryStock gr kaldı!");
    }
    if (_dogWetStock > 0 && _dogWetStock <= threshold) {
      await NotificationService().showInstantNotification(105, "Azalan Stok: Köpek Yaş Mama 🐶", "Stokta sadece $_dogWetStock gr kaldı!");
    }
    if (_dogTreatStock > 0 && _dogTreatStock <= threshold) {
      await NotificationService().showInstantNotification(106, "Azalan Stok: Köpek Ödül Maması 🐶", "Stokta sadece $_dogTreatStock gr kaldı!");
    }
  }

  Future<void> _loadStock() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _catDryStock = (prefs.getInt('stock_cat_dry') ?? 0).clamp(0, 999999);
      _catWetStock = (prefs.getInt('stock_cat_wet') ?? 0).clamp(0, 999999);
      _catTreatStock = (prefs.getInt('stock_cat_treat') ?? 0).clamp(0, 999999);
      
      _dogDryStock = (prefs.getInt('stock_dog_dry') ?? 0).clamp(0, 999999);
      _dogWetStock = (prefs.getInt('stock_dog_wet') ?? 0).clamp(0, 999999);
      _dogTreatStock = (prefs.getInt('stock_dog_treat') ?? 0).clamp(0, 999999);
    });
    _checkStockLevels();
  }

  Future<void> _saveStock() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('stock_cat_dry', _catDryStock);
    await prefs.setInt('stock_cat_wet', _catWetStock);
    await prefs.setInt('stock_cat_treat', _catTreatStock);
    
    await prefs.setInt('stock_dog_dry', _dogDryStock);
    await prefs.setInt('stock_dog_wet', _dogWetStock);
    await prefs.setInt('stock_dog_treat', _dogTreatStock);
  }

  // ➕ Stok Ekleme Dialog
  Future<void> _openAddStockDialog() async {
    final stockCtrl = TextEditingController();
    String targetSpecies = "Kedi"; 
    String targetType = "Kuru Mama";

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Padding(
              padding: EdgeInsets.only(
                left: 16, 
                right: 16, 
                top: 16, 
                bottom: MediaQuery.of(ctx).viewInsets.bottom + 16
              ),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                     Text(
                      "Mama Stoğu Ekle 📦",
                      style: Theme.of(ctx).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                    ),
                  const SizedBox(height: 12),
                  
                  // 1. Kimin İçin?
                  const Text("Kimin İçin?", style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                       ChoiceChip(
                         label: const Text("Kedi 🐱"),
                         selected: targetSpecies == "Kedi",
                         onSelected: (val) {
                           if (val) setModalState(() => targetSpecies = "Kedi");
                         },
                         selectedColor: Colors.orange.shade200,
                       ),
                       const SizedBox(width: 8),
                       ChoiceChip(
                         label: const Text("Köpek 🐶"),
                         selected: targetSpecies == "Köpek",
                         onSelected: (val) {
                           if (val) setModalState(() => targetSpecies = "Köpek");
                         },
                         selectedColor: Colors.blue.shade200,
                       ),
                    ],
                  ),
                  const SizedBox(height: 12),

                  // 2. Mama Türü
                  const Text("Mama Türü?", style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: ["Kuru Mama", "Yaş Mama", "Ödül Maması"].map((type) {
                        return Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: ChoiceChip(
                            label: Text(type),
                            selected: targetType == type,
                            onSelected: (val) {
                              if (val) setModalState(() => targetType = type);
                            },
                            selectedColor: Colors.green.shade200,
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                  const SizedBox(height: 12),

                  TextField(
                    controller: stockCtrl,
                    decoration: const InputDecoration(
                      labelText: "Miktar (gram)",
                      hintText: "Örn: 15000 (15 kg için)",
                      border: OutlineInputBorder(),
                      suffixText: "gr",
                    ),
                    keyboardType: TextInputType.number,
                  ),
                  const SizedBox(height: 12),
                  // Hızlı Ekleme Butonları
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                         100, // Ödül
                         400, // Konserve
                         1500, 
                         3000, 
                         15000
                      ].map((amount) {
                        return Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: ActionChip(
                            label: Text(amount >= 1000 ? "${amount/1000} kg" : "$amount gr"),
                            onPressed: () {
                              stockCtrl.text = amount.toString();
                            },
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        final amount = int.tryParse(stockCtrl.text) ?? 0;
                        if (amount > 0) {
                           setState(() {
                             // Granular Update
                             if (targetSpecies == "Kedi") {
                               if (targetType == "Kuru Mama") _catDryStock += amount;
                               if (targetType == "Yaş Mama") _catWetStock += amount;
                               if (targetType == "Ödül Maması") _catTreatStock += amount;
                             } else {
                               if (targetType == "Kuru Mama") _dogDryStock += amount;
                               if (targetType == "Yaş Mama") _dogWetStock += amount;
                               if (targetType == "Ödül Maması") _dogTreatStock += amount;
                             }
                           });
                           _saveStock();
                           ScaffoldMessenger.of(context).showSnackBar(
                             SnackBar(content: Text("$targetSpecies - $targetType stoğuna $amount gr eklendi!")),
                           );
                        }
                        Navigator.pop(ctx);
                      },
                      child: const Text("Stoka Ekle"),
                    ),
                  ),
                ],
              ),
            ),
            );
          }
        );
      },
    );
  }

  Widget _buildStockRow(String label, int currentGrams, double maxCapacity, Color color) {
    final progress = (currentGrams / maxCapacity).clamp(0.0, 1.0);
    
    // Kullanıcı tam miktarı görmek istiyor: "3500 gr / 15 kg"
    final maxKg = (maxCapacity / 1000).toStringAsFixed(0); // 15
    final textVal = "$currentGrams gr / $maxKg kg";

    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
              Text(textVal, style: TextStyle(fontSize: 12, color: Theme.of(context).brightness == Brightness.dark ? Colors.grey.shade400 : Colors.grey.shade800, fontWeight: FontWeight.w500)),
            ],
          ),
          const SizedBox(height: 4),
          LinearProgressIndicator(
            value: progress,
            backgroundColor: Colors.grey.shade100,
            valueColor: AlwaysStoppedAnimation<Color>(color),
            minHeight: 6,
            borderRadius: BorderRadius.circular(3),
          ),
        ],
      ),
    );
  }

  Widget _buildStockSection() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Theme.of(context).dividerColor.withOpacity(0.1)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                "Mama Stoğu 📦",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              TextButton.icon(
                onPressed: _openAddStockDialog,
                icon: const Icon(Icons.add, size: 18),
                label: const Text("Ekle"),
                style: TextButton.styleFrom(
                  padding: EdgeInsets.zero,
                  minimumSize: const Size(60, 30),
                  tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                ),
              )
            ],
          ),
          const SizedBox(height: 12),
          
          // 🐱 Kedi Bölümü
          Row(children: [const Text("🐱 Kedi", style: TextStyle(fontWeight: FontWeight.bold))]),
          const SizedBox(height: 8),
          _buildStockRow("Kuru Mama", _catDryStock, 15000, Colors.orange),
          _buildStockRow("Yaş Mama", _catWetStock, 5000, Colors.deepOrange),
          _buildStockRow("Ödül", _catTreatStock, 1000, Colors.amber),
          
          const Divider(height: 24),

          // 🐶 Köpek Bölümü
          Row(children: [const Text("🐶 Köpek", style: TextStyle(fontWeight: FontWeight.bold))]),
          const SizedBox(height: 8),
          _buildStockRow("Kuru Mama", _dogDryStock, 20000, Colors.blue),
          _buildStockRow("Yaş Mama", _dogWetStock, 5000, Colors.blueAccent),
          _buildStockRow("Ödül", _dogTreatStock, 1000, Colors.lightBlue),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Bugünkü ve geçmiş kayıtları ayır
    final now = DateTime.now();
    final todayEntries = _entries.where((e) =>
      e.time.year == now.year &&
      e.time.month == now.month &&
      e.time.day == now.day
    ).toList();
    
    final pastEntries = _entries.where((e) =>
      e.time.year != now.year ||
      e.time.month != now.month ||
      e.time.day != now.day
    ).toList();

    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: _openAddDialog,
        backgroundColor: Colors.orange,
        child: const Icon(Icons.add, color: Colors.white),
      ),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 80),
        children: [
          // 1. Daily Recommendation Section
          _buildDailyRecommendationSection(),
          
          // 2. Stock Section
          _buildStockSection(),
          
          // 3. Bugünkü Kayıtlar
          if (todayEntries.isNotEmpty) ...[
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
              child: Row(
                children: [
                  const Icon(Icons.today, size: 20, color: Colors.orange),
                  const SizedBox(width: 8),
                  Text(
                    "Bugün (${todayEntries.length})",
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
            ...todayEntries.map((e) => _buildFoodEntryCard(e)),
          ],
          
          // 4. Geçmiş Kayıtlar
          if (pastEntries.isNotEmpty) ...[
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
              child: Row(
                children: [
                  const Icon(Icons.history, size: 20, color: Colors.grey),
                  const SizedBox(width: 8),
                  Text(
                    "Geçmiş (${pastEntries.length})",
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.grey.shade700,
                    ),
                  ),
                ],
              ),
            ),
            ...pastEntries.map((e) => _buildFoodEntryCard(e)),
          ],
          
          // Boş durum mesajı
          if (_entries.isEmpty)
            Padding(
              padding: const EdgeInsets.all(40),
              child: Column(
                children: [
                  Icon(Icons.restaurant_menu, size: 64, color: Colors.grey.shade300),
                  const SizedBox(height: 16),
                  Text(
                    "Henüz mama kaydı yok",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.grey.shade600,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "Yeni kayıt eklemek için + butonuna basın",
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey.shade500,
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildFoodEntryCard(FoodEntry e) {
    final listIndex = _entries.indexOf(e);
    
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      elevation: 2,
      child: ListTile(
        contentPadding: const EdgeInsets.all(12),
        leading: CircleAvatar(
          backgroundColor: Colors.orange.shade100,
          child: const Icon(Icons.restaurant, color: Colors.orange),
        ),
        title: Text(
          "${e.petName} • ${e.foodType}",
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Text(
          "${e.amountGrams} gr\n${_formatTime(e.time)}",
        ),
        isThreeLine: true,
        trailing: IconButton(
          icon: const Icon(Icons.delete, color: Colors.red),
          onPressed: () {
            // Silinen kaydı stoka geri ekleyelim
            final relatedPet = widget.pets.firstWhere(
              (p) => p.id == e.petId,
              orElse: () => Pet(name: "", type: "Kedi", age: 1, weight: "1", breed: "Bilinmiyor")
            );
            final isCat = relatedPet.type.toLowerCase().contains("kedi");

            setState(() {
              if (isCat) {
                if (e.foodType == "Kuru Mama") _catDryStock += e.amountGrams;
                if (e.foodType == "Yaş Mama") _catWetStock += e.amountGrams;
                if (e.foodType == "Ödül Maması") _catTreatStock += e.amountGrams;
              } else {
                if (e.foodType == "Kuru Mama") _dogDryStock += e.amountGrams;
                if (e.foodType == "Yaş Mama") _dogWetStock += e.amountGrams;
                if (e.foodType == "Ödül Maması") _dogTreatStock += e.amountGrams;
              }

              _entries.removeAt(listIndex);
            });
            _saveEntries();
            _saveStock();
          },
        ),
      ),
    );
  }
}


