import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:mobil1/screens/profile/pet_list_page.dart';
import 'package:mobil1/screens/profile/profile_edit_page.dart';
import 'package:mobil1/models/pet.dart';
import 'package:mobil1/db/pet_database.dart';
import 'package:mobil1/screens/food_tracker/food_tracker_page.dart';
import 'package:mobil1/screens/vaccine/vaccine_page.dart';
import 'package:mobil1/models/food_entry.dart';
import 'package:mobil1/models/vaccine.dart';
import 'package:mobil1/models/appointment.dart';
import 'package:mobil1/screens/appointment/appointment_page.dart';
import 'package:mobil1/screens/settings/settings_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int selectedIndex = 0;
  final List<Pet> pets = [];
  final List<FoodEntry> _foodEntries = [];
  final List<Vaccine> _vaccineAlerts = []; 
  final List<Appointment> _appointmentAlerts = []; // Dashboard için

  // User Data
  String userName = "";
  String userAvatar = "👤";

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    await _loadPets();
    await _loadUserProfile();
    await _loadFoodEntries();
    await _loadVaccineAlerts();
    await _loadAppointmentAlerts();
  }

  Future<void> _loadAppointmentAlerts() async {
    final list = await PetDatabase.instance.getAllAppointments();
    final now = DateTime.now();
    // Sadece tamamlanmamış VE gelecekteki randevuları göster
    final pending = list.where((a) => !a.isDone && a.dateTime.isAfter(now)).toList();
    // Tarihe göre sırala
    pending.sort((a, b) => a.dateTime.compareTo(b.dateTime));

    if (!mounted) return;
    setState(() {
      _appointmentAlerts
        ..clear()
        ..addAll(pending);
    });
  }

  Future<void> _loadVaccineAlerts() async {
    // Tüm hayvanların yaklaşan aşılarını çekelim
    List<Vaccine> allVaccines = [];
    for (var pet in pets) {
      if (pet.id != null) {
        final list = await PetDatabase.instance.getVaccinesForPet(pet.id!);
        allVaccines.addAll(list);
      }
    }
    
    // Sadece tamamlanmamış aşıları filtrele (gecikenler dahil)
    final upcoming = allVaccines.where((v) => !v.isDone).toList();
    
    // Tarihe göre sırala (En yakın en üstte)
    upcoming.sort((a, b) => a.date.compareTo(b.date));

    if (!mounted) return;
    setState(() {
      _vaccineAlerts
        ..clear()
        ..addAll(upcoming);
    });
  }

  Future<void> _loadFoodEntries() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('food_entries');
    if (raw == null) return;
    try {
      final List decoded = jsonDecode(raw);
      if (!mounted) return;
      setState(() {
        _foodEntries
          ..clear()
          ..addAll(decoded.map((e) => FoodEntry.fromJson(e as Map<String, dynamic>)));
      });
    } catch (e) {
      debugPrint("Food entries load error: $e");
    }
  }

  Future<void> _loadUserProfile() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      userName = prefs.getString('user_name') ?? "Kullanıcı";
      userAvatar = prefs.getString('user_avatar') ?? "👤";
    });
  }

  // ... (Existing Database Methods: _loadPets, _addPet, _updatePet, _deletePet are SAME)

  Future<void> _loadPets() async {
    try {
      final items = await PetDatabase.instance.getAllPets();
      setState(() {
        pets
          ..clear()
          ..addAll(items);
      });
    } catch (e) {
      _showError("Veritabanı okunamadı: $e");
    }
  }

  Future<void> _addPet(Pet pet) async {
    try {
      final id = await PetDatabase.instance.insertPet(pet);
      final saved = pet.copyWith(id: id);
      setState(() {
        pets.insert(0, saved);
      });
      await _loadPets();
      await _loadVaccineAlerts();
    } catch (e) {
      _showError("Kaydedilemedi: $e");
    }
  }

  Future<void> _updatePet(int index, Pet pet) async {
    try {
      final currentId = pets[index].id;
      final toSave = pet.copyWith(id: currentId);
      await PetDatabase.instance.updatePet(toSave);
      setState(() {
        pets[index] = toSave;
      });
      await _loadPets();
      await _loadVaccineAlerts();
    } catch (e) {
      _showError("Güncellenemedi: $e");
    }
  }

  Future<void> _deletePet(int index) async {
    try {
      final pet = pets[index];
      if (pet.id != null) {
        await PetDatabase.instance.deletePet(pet.id!);
        // Cascade delete implementation for food entries...
        final prefs = await SharedPreferences.getInstance();
        final raw = prefs.getString('food_entries');
        if (raw != null) {
          List<dynamic> decoded = jsonDecode(raw);
          decoded.removeWhere((item) => item['petId'] == pet.id);
          final updatedData = jsonEncode(decoded);
          await prefs.setString('food_entries', updatedData);
        }
      }
      setState(() {
        pets.removeAt(index);
      });
      await _loadPets();
      await _loadVaccineAlerts();
    } catch (e) {
      _showError("Silinemedi: $e");
    }
  }

  void _showError(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg)),
    );
  }

  // 🏠 DASHBOARD (ANA SAYFA)
  Widget _buildDashboard() {
    return SingleChildScrollView(
      padding: const EdgeInsets.only(bottom: 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 20),
          // 1. Slider Başlık
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  "Dostlarım 🐾",
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                ),
                Text(
                  "${pets.length} Kayıtlı",
                  style: const TextStyle(color: Colors.grey),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          
          // 2. Pet Slider (PageView)
          SizedBox(
            height: 220,
            child: PageView.builder(
              controller: PageController(viewportFraction: 0.85),
              itemCount: pets.length + 1, // +1 for "Add New" card
              itemBuilder: (context, index) {
                if (index == pets.length) {
                  return _buildAddPetCard();
                }
                return _buildPetCard(pets[index]);
              },
            ),
          ),
          
          const SizedBox(height: 32),
          
          // 3. Alt Dashboard (Summary)
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 20),
            child: Text(
              "Bugünün Özeti 📊",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ),
          const SizedBox(height: 12),
          
          // 🧮 Mama Durumu Hesaplama
          Builder(
            builder: (context) {
              final now = DateTime.now();
              // Bugün beslenen benzersiz petId'ler
              final fedTodayIds = _foodEntries.where((e) => 
                e.time.year == now.year && 
                e.time.month == now.month && 
                e.time.day == now.day
              ).map((e) => e.petId).toSet();
              
              final totalPets = pets.length;
              final fedCount = fedTodayIds.length;
              
              String statusText;
              if (totalPets == 0) {
                statusText = "Henüz hayvan eklemediniz.";
              } else if (fedCount == 0) {
                statusText = "Henüz kimse beslenmedi. 🥣";
              } else if (fedCount < totalPets) {
                statusText = "$fedCount / $totalPets dostumuz beslendi.";
              } else {
                statusText = "Tüm dostlarımız doydu! ✨";
              }

              return _buildSummaryCard(
                "🦴 Mama Durumu",
                statusText,
                Icons.restaurant_menu,
                fedCount == totalPets && totalPets > 0 ? Colors.green : Colors.orange,
                onTap: () => setState(() => selectedIndex = 1),
              );
            }
          ),
          
          // 🧮 Aşı Durumu Hesaplama
          Builder(
            builder: (context) {
              // Yapılmamış aşıları bul
              final upcoming = _vaccineAlerts.where((v) => !v.isDone).toList();
              
              String vaccineText;
              if (upcoming.isEmpty) {
                vaccineText = "Yakın zamanda aşı yok.";
              } else {
                final nextV = upcoming.first;
                final now = DateTime.now();
                final diff = nextV.date.difference(DateTime(now.year, now.month, now.day)).inDays;
                
                if (diff < 0) {
                  vaccineText = "Gecikmiş Aşı: ${nextV.name} 🚨";
                } else if (diff == 0) {
                  vaccineText = "Bugün: ${nextV.name} yapılacak! ⚠️";
                } else {
                  vaccineText = "Sıradaki: ${nextV.name} ($diff gün kaldı)";
                }
              }

              final isUrgent = upcoming.any((v) => !v.isDone && v.date.isBefore(DateTime.now()));

              return _buildSummaryCard(
                "💉 Aşı Takvimi",
                vaccineText,
                Icons.vaccines,
                isUrgent ? Colors.redAccent : Colors.blue,
                onTap: () => setState(() => selectedIndex = 2),
              );
            }
          ),

          // 🧮 Randevu Durumu Hesaplama
          Builder(
            builder: (context) {
              String appText;
              bool isUrgent = false;

              if (_appointmentAlerts.isEmpty) {
                appText = "Gelecek randevunuz yok.";
              } else {
                final nextA = _appointmentAlerts.first;
                final now = DateTime.now();
                final diff = nextA.dateTime.difference(now).inDays;
                
                if (diff < 0) {
                  appText = "Gecikmiş: ${nextA.title} 🚨";
                  isUrgent = true;
                } else if (diff == 0) {
                  final hours = nextA.dateTime.difference(now).inHours;
                  appText = hours > 0 
                    ? "Bugün $hours saat sonra: ${nextA.title}" 
                    : "Randevu Zamanı: ${nextA.title} ⚠️";
                  isUrgent = true;
                } else {
                  appText = "Sıradaki: ${nextA.title} ($diff gün kaldı)";
                }
              }

              return _buildSummaryCard(
                "📅 Randevular",
                appText,
                Icons.calendar_today,
                isUrgent ? Colors.redAccent : Colors.green,
                onTap: () => setState(() => selectedIndex = 3),
              );
            }
          ),
          _buildSummaryCard(
            "💡 Günün İpucu",
            "Kediler günde ortalama 12-16 saat uyurlar. 😴",
            Icons.lightbulb,
            Colors.purple,
          ),
        ],
      ),
    );
  }

  Widget _buildPetCard(Pet pet) {
    // Avatar logic reuse? Or simple check here.
    Widget avatarWidget;
    if (pet.imagePath != null && pet.imagePath!.startsWith("avatar:")) {
       avatarWidget = Text(
         pet.imagePath!.replaceAll("avatar:", ""), 
         style: const TextStyle(fontSize: 60),
       );
    } else if (pet.imagePath != null) {
       avatarWidget = CircleAvatar(
         radius: 40,
         backgroundImage: FileImage(File(pet.imagePath!)),
       );
    } else {
       avatarWidget = Image.asset(
          pet.type == "Köpek" ? 'assets/images/avatars/dog.png' : 'assets/images/avatars/cat.png',
          width: 80,
       );
    }

    return GestureDetector(
      onTap: () {
        // Detaya git (şimdilik direkt Mama sayfasına yönlendirelim veya düzenle)
        // Kullanıcı "Detail Page" istemişti ama şu an elimizdeki tek detay "ProfileEdit" 
        // ya da "FoodTracker". 
        // Şimdilik ProfileEditPage'i "View" modunda açmak mantıklı olabilir.
        // Ama ProfileEditPage "Edit" sayfası.
        // En iyisi FoodTracker sayfasına (index 1) geçiş yapmak?
        // Kullanıcı: "bu anasayfada hayvanlar slider şeklinde gözüksün" dedicated page istememiş.
        // Tıklayınca ProfileEditPage açalım şimdilik.
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => ProfileEditPage(pet: pet)),
        ).then((updated) {
          if (updated != null && updated is Pet) {
             // update logic call
             final idx = pets.indexWhere((p) => p.id == pet.id);
             if (idx != -1) _updatePet(idx, updated);
          }
        });
      },
      child: Container(
        margin: const EdgeInsets.only(right: 12),
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(24),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            avatarWidget,
            const SizedBox(height: 12),
            Text(
              pet.name,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            Text(
              "${pet.breed} • ${pet.age} Yaş",
              style: TextStyle(color: Theme.of(context).hintColor),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAddPetCard() {
    return GestureDetector(
      onTap: () async {
        final Pet? newPet = await Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const ProfileEditPage()),
        );
         if (newPet != null) {
            await _addPet(newPet);
          }
      },
      child: Container(
        margin: const EdgeInsets.only(right: 12),
        decoration: BoxDecoration(
          color: Theme.of(context).brightness == Brightness.dark ? Colors.grey.shade900 : Colors.grey.shade100,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: Theme.of(context).dividerColor, style: BorderStyle.solid),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: const BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.add, size: 32, color: Colors.blue),
            ),
            const SizedBox(height: 12),
            Text(
              "Yeni Ekle",
              style: TextStyle(fontWeight: FontWeight.bold, color: Theme.of(context).hintColor),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryCard(String title, String subtitle, IconData icon, Color color, {VoidCallback? onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Theme.of(context).dividerColor.withOpacity(0.05)),
          boxShadow: [
            if (onTap != null)
              BoxShadow(
                color: Colors.black.withOpacity(0.02),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: color),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  const SizedBox(height: 4),
                  Text(subtitle, style: TextStyle(color: Colors.grey.shade600, fontSize: 13)),
                ],
              ),
            ),
            if (onTap != null)
              const Icon(Icons.chevron_right, color: Colors.grey, size: 20),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Navigasyon sayfaları
    final pages = [
      _buildDashboard(), // 0. Ana Sayfa
      FoodTrackerPage(pets: pets), // 1. Mama Takibi
      VaccinePage(pets: pets), // 2. Aşı Takvimi
      AppointmentPage(pets: pets), // 3. Randevu Takibi
      const SettingsPage(), // 4. Ayarlar
    ];

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor, // Hafif gri arka plan
      appBar: AppBar(
        backgroundColor: Theme.of(context).cardColor,
        elevation: 0,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Merhaba,",
              style: TextStyle(fontSize: 14, color: Colors.grey),
            ),
            Text(
              "$userName 👋",
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16.0),
            child: CircleAvatar(
              backgroundColor: Colors.blue.shade50,
              child: Text(userAvatar, style: const TextStyle(fontSize: 24)),
            ),
          )
        ],
      ),
      body: pages[selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: selectedIndex,
        onTap: (index) {
          setState(() => selectedIndex = index);
          // 🆕 Verileri tazele
          if (index == 0) {
            _loadFoodEntries();
            _loadVaccineAlerts();
            _loadAppointmentAlerts();
            _loadUserProfile();
          } else if (index == 2) {
             _loadVaccineAlerts();
          } else if (index == 3) {
             _loadAppointmentAlerts();
          }
        },
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Colors.blueAccent,
        unselectedItemColor: Colors.grey,
        showUnselectedLabels: true,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home_rounded), label: "Ana Sayfa"),
          BottomNavigationBarItem(icon: Icon(Icons.restaurant), label: "Mama"),
          BottomNavigationBarItem(icon: Icon(Icons.vaccines), label: "Aşı"),
          BottomNavigationBarItem(icon: Icon(Icons.calendar_today), label: "Randevu"),
          BottomNavigationBarItem(icon: Icon(Icons.settings), label: "Ayarlar"),
        ],
      ),
    );
  }
}
