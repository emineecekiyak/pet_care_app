import 'package:flutter/material.dart';
import 'package:mobil1/models/pet.dart';
import 'package:mobil1/models/vaccine.dart';
import 'package:mobil1/db/pet_database.dart';
import 'package:mobil1/services/notification_service.dart';

class VaccinePage extends StatefulWidget {
  final List<Pet> pets;

  const VaccinePage({super.key, required this.pets});

  @override
  State<VaccinePage> createState() => _VaccinePageState();
}

class _VaccinePageState extends State<VaccinePage> {
  Pet? _selectedPet;
  List<Vaccine> _vaccines = [];
  List<Vaccine> _allUpcomingVaccines = [];
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    if (widget.pets.isNotEmpty) {
      _selectedPet = widget.pets.first;
      _loadVaccines();
    }
  }

  @override
  void didUpdateWidget(covariant VaccinePage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.pets.length != oldWidget.pets.length) {
      if (_selectedPet == null && widget.pets.isNotEmpty) {
        _selectedPet = widget.pets.first;
        _loadVaccines();
      }
    }
  }

  Future<void> _loadVaccines() async {
    setState(() => _isLoading = true);
    try {
      // 1. Tüm aşıları çek (Global timeline için)
      List<Vaccine> globalList = [];
      for (var p in widget.pets) {
        if (p.id != null) {
          final pVaccines = await PetDatabase.instance.getVaccinesForPet(p.id!);
          globalList.addAll(pVaccines);
        }
      }
      
      // 2. Filtreli listeyi al (Seçili hayvan geçmişi için)
      final List<Vaccine> filtered;
      if (_selectedPet == null || _selectedPet!.id == null) {
        filtered = [];
      } else {
        filtered = globalList.where((v) => v.petId == _selectedPet!.id).toList();
      }

      // 3. Yaklaşanları ayıkla (Tamamlanmamış aşılar - gecikenler dahil)
      final upcoming = globalList.where((v) => !v.isDone).toList();
      upcoming.sort((a, b) => a.date.compareTo(b.date));

      setState(() {
        _allUpcomingVaccines = upcoming;
        _vaccines = filtered;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      _showError("Aşılar yüklenemedi: $e");
    }
  }

  Future<void> _applyTemplate() async {
    if (_selectedPet == null || _selectedPet!.id == null) return;

    final isCat = _selectedPet!.type.toLowerCase().contains("kedi");
    // [İsim, Frekans(Ay)]
    final List<List<dynamic>> templates = isCat
        ? [
            ["İç/Dış Parazit", 2],
            ["Karma Aşı", 12],
            ["Kuduz Aşısı (Zorunlu)", 12],
            ["Lösemi Aşısı", 12],
          ]
        : [
            ["İç/Dış Parazit", 2],
            ["Karma Aşı", 12],
            ["Kuduz Aşısı (Zorunlu)", 12],
            ["Corona Aşısı", 12],
            ["Bronchine", 12],
          ];

    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text("${_selectedPet!.name} İçin Şablon Uygula"),
        content: Text("${templates.length} adet önerilen aşı/uygulama listeye eklenecek. Devam edilsin mi?"),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text("İptal")),
          ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text("Evet, Ekle")),
        ],
      ),
    );

    if (confirm == true) {
      setState(() => _isLoading = true);
      for (int i = 0; i < templates.length; i++) {
        final v = Vaccine(
          petId: _selectedPet!.id!,
          name: templates[i][0] as String,
          frequencyMonths: templates[i][1] as int,
          date: DateTime.now().add(Duration(days: (i + 1) * 7)),
          isDone: false,
        );
        final id = await PetDatabase.instance.insertVaccine(v);
        
        // Schedule reminder for templates at 09:00
        final reminderTime = DateTime(v.date.year, v.date.month, v.date.day, 9, 0);
        await NotificationService().scheduleNotification(
          id, 
          "Aşı Hatırlatıcısı 💉",
          "${_selectedPet!.name} dostumuzun bugün ${v.name} aşısı yapılması gerekiyor.",
          reminderTime,
        );
      }
      await _loadVaccines();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Önerilen aşı takvimi başarıyla oluşturuldu!")),
        );
      }
    }
  }

  Future<void> _addVaccine() async {
    if (_selectedPet == null) return;

    final nameController = TextEditingController();
    final noteController = TextEditingController();
    final freqController = TextEditingController();
    DateTime selectedDate = DateTime.now();

    final isCat = _selectedPet!.type.toLowerCase().contains("kedi");
    // [İsim, Frekans, İkon]
    final List<Map<String, dynamic>> suggestions = isCat
        ? [
            {"name": "İç/Dış Parazit", "freq": 2, "icon": Icons.bug_report_outlined},
            {"name": "Karma Aşı", "freq": 12, "icon": Icons.shield_outlined},
            {"name": "Kuduz Aşısı", "freq": 12, "icon": Icons.warning_amber_rounded},
            {"name": "Lösemi Aşısı", "freq": 12, "icon": Icons.health_and_safety_outlined},
          ]
        : [
            {"name": "İç/Dış Parazit", "freq": 2, "icon": Icons.bug_report_outlined},
            {"name": "Karma Aşı", "freq": 12, "icon": Icons.shield_outlined},
            {"name": "Kuduz Aşısı", "freq": 12, "icon": Icons.warning_amber_rounded},
            {"name": "Corona Aşısı", "freq": 12, "icon": Icons.coronavirus_outlined},
            {"name": "Bronchine", "freq": 12, "icon": Icons.air_outlined},
          ];

    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: Row(
            children: [
              const Icon(Icons.auto_awesome, color: Colors.blueAccent),
              const SizedBox(width: 8),
              const Text("Akıllı Aşı Ekle"),
            ],
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Hızlı Seçim", style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Colors.blueGrey)),
                const SizedBox(height: 12),
                // Grid-like layout for suggestions
                Column(
                  children: suggestions.map((s) => Padding(
                    padding: const EdgeInsets.only(bottom: 8.0),
                    child: InkWell(
                      onTap: () {
                        setDialogState(() {
                          nameController.text = s['name'];
                          freqController.text = s['freq'].toString();
                        });
                      },
                      borderRadius: BorderRadius.circular(12),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: nameController.text == s['name'] ? Colors.blueAccent : Colors.grey.shade200,
                            width: nameController.text == s['name'] ? 2 : 1,
                          ),
                          borderRadius: BorderRadius.circular(12),
                          color: nameController.text == s['name'] ? Colors.blue.shade50 : Colors.white,
                        ),
                        child: Row(
                          children: [
                            Icon(s['icon'] as IconData, size: 20, color: Colors.blueAccent),
                            const SizedBox(width: 12),
                            Expanded(child: Text(s['name'] as String, style: const TextStyle(fontSize: 14))),
                            Text("${s['freq']} Ay", style: TextStyle(fontSize: 12, color: Colors.orange.shade800, fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ),
                    ),
                  )).toList(),
                ),
                const SizedBox(height: 24),
                const Text("Manuel Detaylar", style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Colors.blueGrey)),
                const SizedBox(height: 12),
                TextField(
                  controller: nameController,
                  decoration: const InputDecoration(
                    labelText: "Aşı Adı",
                    prefixIcon: Icon(Icons.edit_outlined),
                    border: OutlineInputBorder(),
                    contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: freqController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: "Tekrar Sıklığı (Ay)",
                    hintText: "Örn: 12",
                    border: OutlineInputBorder(),
                    helperText: "Bu aşı kaç ayda bir tekrarlanmalı?",
                  ),
                ),
                const SizedBox(height: 16),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  tileColor: Colors.blue.shade50,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  leading: const Padding(
                    padding: EdgeInsets.only(left: 8.0),
                    child: Icon(Icons.calendar_today, color: Colors.blue),
                  ),
                  title: const Text("Aşı Tarihi", style: TextStyle(fontSize: 14)),
                  subtitle: Text("${selectedDate.day}.${selectedDate.month}.${selectedDate.year}", 
                      style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.blue)),
                  onTap: () async {
                    final picked = await showDatePicker(
                      context: context,
                      initialDate: selectedDate,
                      firstDate: DateTime.now().subtract(const Duration(days: 365)),
                      lastDate: DateTime.now().add(const Duration(days: 1000)),
                    );
                    if (picked != null) {
                      setDialogState(() => selectedDate = picked);
                    }
                  },
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: noteController,
                  decoration: const InputDecoration(
                    labelText: "Notlar (Opsiyonel)",
                    border: OutlineInputBorder(),
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text("İptal")),
            ElevatedButton(
              onPressed: () async {
                if (nameController.text.trim().isEmpty) return;
                
                final v = Vaccine(
                  petId: _selectedPet!.id!,
                  name: nameController.text.trim(),
                  date: selectedDate,
                  frequencyMonths: int.tryParse(freqController.text),
                  note: noteController.text.trim().isEmpty ? null : noteController.text.trim(),
                );
                final id = await PetDatabase.instance.insertVaccine(v);
                
                // Schedule reminder at 09:00 on the day of vaccine
                final reminderTime = DateTime(selectedDate.year, selectedDate.month, selectedDate.day, 9, 0);
                await NotificationService().scheduleNotification(
                  id, // Use DB id for notification id
                  "Aşı Hatırlatıcısı 💉",
                  "${_selectedPet!.name} dostumuzun bugün ${v.name} aşısı yapılması gerekiyor.",
                  reminderTime,
                );

                if (ctx.mounted) {
                  Navigator.pop(ctx, true);
                }
              },
              child: const Text("Kaydet"),
            ),
          ],
        ),
      ),
    );

    if (result == true) {
      _loadVaccines();
    }
  }

  Future<void> _renewVaccine(Vaccine vaccine) async {
    if (vaccine.frequencyMonths == null) {
      _showError("Bu aşının bir periyot bilgisi yok, otomatik tekrarlanamaz.");
      return;
    }

    final nextDetail = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("Gelecek Dozu Planla"),
        content: Text("${vaccine.name} aşısının bir sonraki dozu ${vaccine.frequencyMonths} ay sonrasına planlanacak.\n\nEmin misiniz?"),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text("Vazgeç")),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text("Planla"),
          ),
        ],
      ),
    );

    if (nextDetail == true) {
      // Yeni tarihi hesapla (Ay ekleme)
      final DateTime originalDate = vaccine.date;
      final DateTime nextDate = DateTime(
        originalDate.year,
        originalDate.month + vaccine.frequencyMonths!,
        originalDate.day,
      );

      final nextV = Vaccine(
        petId: vaccine.petId,
        name: vaccine.name,
        date: nextDate,
        isDone: false,
        note: vaccine.note,
        frequencyMonths: vaccine.frequencyMonths,
      );

      final id = await PetDatabase.instance.insertVaccine(nextV);

      // Schedule reminder for renewed vaccine at 09:00
      final reminderTime = DateTime(nextV.date.year, nextV.date.month, nextV.date.day, 9, 0);
      await NotificationService().scheduleNotification(
        id, 
        "Aşı Hatırlatıcısı 💉",
        "${_selectedPet!.name} dostumuzun bugün ${nextV.name} aşısı yapılması gerekiyor.",
        reminderTime,
      );
      await _loadVaccines();
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Gelecek doz ${nextDate.day}.${nextDate.month}.${nextDate.year} tarihine eklendi! 📅")),
        );
      }
    }
  }

  Future<void> _toggleDone(Vaccine vaccine) async {
    final updated = vaccine.copyWith(isDone: !vaccine.isDone);
    await PetDatabase.instance.updateVaccine(updated);
    _loadVaccines();
  }

  Future<void> _deleteVaccine(Vaccine vaccine) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("Aşıyı Sil?"),
        content: const Text("Bu kayıt silinecek, emin misiniz?"),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text("İptal")),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text("Sil", style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (confirm == true) {
      await PetDatabase.instance.deleteVaccine(vaccine.id!);
      _loadVaccines();
    }
  }

  void _showError(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: widget.pets.isEmpty
          ? const Center(child: Text("Önce bir hayvan eklemelisiniz."))
          : Column(
              children: [
                _buildPetSelector(),
                Expanded(
                  child: _isLoading
                      ? const Center(child: CircularProgressIndicator())
                      : (_vaccines.isEmpty && _allUpcomingVaccines.isEmpty)
                          ? _buildEmptyState()
                          : ListView(
                              padding: EdgeInsets.zero,
                              children: [
                                if (_allUpcomingVaccines.isNotEmpty) ...[
                                  _buildUpcomingSection(_allUpcomingVaccines),
                                  const Padding(
                                    padding: EdgeInsets.fromLTRB(16, 24, 16, 8),
                                    child: Text(
                                      "Aşı Geçmişi ve Kayıtlar",
                                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                ],
                                _buildVaccineList(_vaccines),
                              ],
                            ),
                ),
              ],
            ),
      floatingActionButton: widget.pets.isNotEmpty
          ? FloatingActionButton.extended(
              onPressed: _addVaccine,
              icon: const Icon(Icons.add),
              label: const Text("Aşı Ekle"),
              backgroundColor: Colors.blueAccent,
            )
          : null,
    );
  }

  Widget _buildUpcomingSection(List<Vaccine> upcoming) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
          child: Text(
            "Planlanan Aşılar ⭐ (Tümü)",
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
        ),
        SizedBox(
          height: 155,
          child: ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            scrollDirection: Axis.horizontal,
            itemCount: upcoming.length,
            itemBuilder: (context, index) {
              final v = upcoming[index];
              final pet = widget.pets.cast<Pet?>().firstWhere((p) => p?.id == v.petId, orElse: () => null);
              final petName = pet?.name ?? "Bilinmiyor";

              final now = DateTime.now();
              final bool isOverdue = v.date.isBefore(now);
              final bool isSoon = !isOverdue && v.date.difference(now).inDays < 90;
              
              return Container(
                width: 210,
                margin: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: isOverdue 
                      ? [Colors.red.shade400, Colors.red.shade600]
                      : [Colors.orange.shade300, Colors.orange.shade500],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: (isOverdue ? Colors.red : Colors.orange).withOpacity(0.3),
                      blurRadius: 8,
                      offset: const Offset(0, 4),
                    )
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            petName,
                            style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold),
                          ),
                        ),
                        Text(
                          isOverdue ? "Gecikti!" : (isSoon ? "Yakında" : ""),
                          style: const TextStyle(color: Colors.white70, fontSize: 10, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                    Text(
                      v.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15),
                    ),
                    Row(
                      children: [
                        const Icon(Icons.event, color: Colors.white70, size: 14),
                        const SizedBox(width: 4),
                        Text(
                          "${v.date.day}.${v.date.month}.${v.date.year}",
                          style: const TextStyle(color: Colors.white, fontSize: 13),
                        ),
                      ],
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildPetSelector() {
    return Container(
      padding: const EdgeInsets.all(16),
      color: Theme.of(context).cardColor,
      child: DropdownButtonFormField<Pet>(
        value: _selectedPet,
        decoration: InputDecoration(
          labelText: "Hayvan Seçin",
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
          prefixIcon: const Icon(Icons.pets),
        ),
        items: widget.pets
            .map((p) => DropdownMenuItem(value: p, child: Text(p.name)))
            .toList(),
        onChanged: (val) {
          setState(() {
            _selectedPet = val;
            _loadVaccines();
          });
        },
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 40),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.vaccines_outlined, size: 80, color: Colors.grey.shade300),
            const SizedBox(height: 16),
            const Text(
              "Henüz aşı kaydı yok.",
              style: TextStyle(fontSize: 18, color: Colors.grey, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text(
              "Dostunuzun sağlığı için aşılarını ekleyin veya şablonu kullanın.",
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey),
            ),
            const SizedBox(height: 24),
            OutlinedButton.icon(
              onPressed: _applyTemplate,
              icon: const Icon(Icons.auto_awesome),
              label: const Text("Önerilen Aşıları Otomatik Ekle"),
              style: OutlinedButton.styleFrom(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                side: const BorderSide(color: Colors.blueAccent),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildVaccineList(List<Vaccine> list) {
    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      padding: const EdgeInsets.all(16),
      itemCount: list.length,
      itemBuilder: (context, index) {
        final v = list[index];
        final bool isOverdue = !v.isDone && v.date.isBefore(DateTime.now());
        
        return Card(
          elevation: 2,
          margin: const EdgeInsets.only(bottom: 12),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            leading: CircleAvatar(
              backgroundColor: v.isDone 
                ? Colors.green.shade100 
                : (isOverdue ? Colors.red.shade100 : Colors.blue.shade100),
              child: Icon(
                v.isDone ? Icons.check : Icons.vaccines,
                color: v.isDone 
                  ? Colors.green 
                  : (isOverdue ? Colors.red : Colors.blue),
              ),
            ),
            title: Text(
              v.name,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                decoration: v.isDone ? TextDecoration.lineThrough : null,
              ),
            ),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Wrap(
                  spacing: 8,
                  runSpacing: 4,
                  children: [
                    Text("${v.date.day}.${v.date.month}.${v.date.year}"),
                    if (isOverdue)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: Colors.red.shade50,
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          "Zamanı Geçti",
                          style: TextStyle(fontSize: 10, color: Colors.red.shade900, fontWeight: FontWeight.bold),
                        ),
                      ),
                    if (v.frequencyMonths != null) 
                       Container(
                         padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                         decoration: BoxDecoration(
                           color: Colors.orange.shade50,
                           borderRadius: BorderRadius.circular(4),
                         ),
                         child: Text(
                           "Her ${v.frequencyMonths} Ay",
                           style: TextStyle(fontSize: 10, color: Colors.orange.shade900, fontWeight: FontWeight.bold),
                         ),
                       )
                    else
                       Text("(Sıklık Belirtilmedi)", style: TextStyle(fontSize: 10, color: Colors.grey.shade400)),
                  ],
                ),
                if (v.note != null) 
                  Text(v.note!, style: const TextStyle(fontSize: 12, fontStyle: FontStyle.italic)),
              ],
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  visualDensity: VisualDensity.compact,
                  iconSize: 20,
                  tooltip: "Tamamlandı / Geri Al",
                  icon: Icon(
                    v.isDone ? Icons.undo : Icons.check_circle_outline,
                    color: v.isDone ? Colors.grey : Colors.green,
                  ),
                  onPressed: () => _toggleDone(v),
                ),
                if (v.frequencyMonths != null)
                  IconButton(
                    visualDensity: VisualDensity.compact,
                    iconSize: 20,
                    tooltip: "Gelecek Dozu Planla",
                    icon: const Icon(Icons.event_repeat, color: Colors.orange),
                    onPressed: () => _renewVaccine(v),
                  ),
                IconButton(
                  visualDensity: VisualDensity.compact,
                  iconSize: 20,
                  tooltip: "Sil",
                  icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                  onPressed: () => _deleteVaccine(v),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
