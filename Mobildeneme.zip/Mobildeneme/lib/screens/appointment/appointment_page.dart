import 'package:flutter/material.dart';
import 'package:mobil1/models/pet.dart';
import 'package:mobil1/models/appointment.dart';
import 'package:mobil1/db/pet_database.dart';
import 'package:mobil1/services/notification_service.dart';

class AppointmentPage extends StatefulWidget {
  final List<Pet> pets;

  const AppointmentPage({super.key, required this.pets});

  @override
  State<AppointmentPage> createState() => _AppointmentPageState();
}

class _AppointmentPageState extends State<AppointmentPage> {
  List<Appointment> _appointments = [];
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _loadAppointments();
  }

  Future<void> _loadAppointments() async {
    setState(() => _isLoading = true);
    final list = await PetDatabase.instance.getAllAppointments();
    if (mounted) {
      setState(() {
        _appointments = list;
        _isLoading = false;
      });
    }
  }

  Future<void> _addAppointment() async {
    if (widget.pets.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Önce bir hayvan eklemelisiniz.")),
      );
      return;
    }

    final titleController = TextEditingController();
    final descController = TextEditingController();
    final locController = TextEditingController();
    final costController = TextEditingController();
    DateTime selectedDate = DateTime.now();
    TimeOfDay selectedTime = TimeOfDay.now();
    Pet selectedPet = widget.pets.first;
    String selectedCategory = "Veteriner";

    final categories = [
      {"name": "Veteriner", "icon": Icons.medical_services_outlined},
      {"name": "Bakım", "icon": Icons.content_cut_outlined},
      {"name": "Eğitim", "icon": Icons.school_outlined},
      {"name": "Oyun", "icon": Icons.sports_esports_outlined},
      {"name": "Diğer", "icon": Icons.more_horiz_outlined},
    ];

    await showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text("Yeni Randevu Ekle"),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<Pet>(
                  value: selectedPet,
                  decoration: const InputDecoration(labelText: "Hayvan"),
                  items: widget.pets.map((p) => DropdownMenuItem(value: p, child: Text(p.name))).toList(),
                  onChanged: (p) => setDialogState(() => selectedPet = p!),
                ),
                TextField(
                  controller: titleController,
                  decoration: const InputDecoration(labelText: "Randevu Başlığı"),
                ),
                DropdownButtonFormField<String>(
                  value: selectedCategory,
                  decoration: const InputDecoration(labelText: "Kategori"),
                  items: categories.map((c) => DropdownMenuItem(value: c['name'] as String, child: Text(c['name'] as String))).toList(),
                  onChanged: (c) => setDialogState(() => selectedCategory = c!),
                ),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text("Tarih ve Saat"),
                  subtitle: Text("${selectedDate.day}.${selectedDate.month}.${selectedDate.year} - ${selectedTime.format(context)}"),
                  onTap: () async {
                    final d = await showDatePicker(
                      context: context,
                      initialDate: selectedDate,
                      firstDate: DateTime.now(),
                      lastDate: DateTime.now().add(const Duration(days: 365)),
                    );
                    if (d != null) {
                      final t = await showTimePicker(
                        context: context,
                        initialTime: selectedTime,
                      );
                      if (t != null) {
                        setDialogState(() {
                          selectedDate = d;
                          selectedTime = t;
                        });
                      }
                    }
                  },
                ),
                TextField(
                  controller: locController,
                  decoration: const InputDecoration(labelText: "Konum / Klinik Adı"),
                ),
                TextField(
                  controller: costController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: "Tahmini Maliyet (₺)"),
                ),
                TextField(
                  controller: descController,
                  decoration: const InputDecoration(labelText: "Notlar"),
                  maxLines: 2,
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text("İptal")),
            ElevatedButton(
              onPressed: () async {
                if (titleController.text.isEmpty) return;
                
                final dt = DateTime(
                  selectedDate.year,
                  selectedDate.month,
                  selectedDate.day,
                  selectedTime.hour,
                  selectedTime.minute,
                );

                final app = Appointment(
                  petId: selectedPet.id!,
                  title: titleController.text,
                  description: descController.text,
                  dateTime: dt,
                  category: selectedCategory,
                  location: locController.text,
                  cost: double.tryParse(costController.text),
                );

                final id = await PetDatabase.instance.insertAppointment(app);

                // Schedule reminder at 09:00 on the day of appointment
                final reminderTime = DateTime(dt.year, dt.month, dt.day, 9, 0);
                await NotificationService().scheduleNotification(
                  id + 10000, // Offset to avoid ID collision with vaccines
                  "Randevu Hatırlatıcısı 🗓️",
                  "${selectedPet.name} dostumuzun bugün ${app.title} randevusu var.",
                  reminderTime,
                );
                Navigator.pop(ctx);
                _loadAppointments();
              },
              child: const Text("Kaydet"),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _toggleStatus(Appointment app) async {
    final updated = app.copyWith(isDone: !app.isDone);
    await PetDatabase.instance.updateAppointment(updated);
    _loadAppointments();
  }

  Future<void> _deleteAppointment(int id) async {
    await PetDatabase.instance.deleteAppointment(id);
    _loadAppointments();
  }

  IconData _getCategoryIcon(String category) {
    switch (category) {
      case "Veteriner": return Icons.medical_services_outlined;
      case "Bakım": return Icons.content_cut_outlined;
      case "Eğitim": return Icons.school_outlined;
      case "Oyun": return Icons.sports_esports_outlined;
      default: return Icons.more_horiz_outlined;
    }
  }

  @override
  Widget build(BuildContext context) {
    final upcoming = _appointments.where((a) => !a.isDone).toList();
    final completed = _appointments.where((a) => a.isDone).toList();

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _appointments.isEmpty
              ? _buildEmptyState()
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    if (upcoming.isNotEmpty) ...[
                      const Text("Bekleyen Randevular", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 12),
                      ...upcoming.map((a) => _buildAppointmentCard(a)),
                    ],
                    if (completed.isNotEmpty) ...[
                      const SizedBox(height: 24),
                      const Text("Tamamlananlar", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.grey)),
                      const SizedBox(height: 12),
                      ...completed.map((a) => _buildAppointmentCard(a)),
                    ],
                  ],
                ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addAppointment,
        backgroundColor: Colors.blueAccent,
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildAppointmentCard(Appointment app) {
    final pet = widget.pets.cast<Pet?>().firstWhere((p) => p?.id == app.petId, orElse: () => null);
    final String petName = pet?.name ?? "Bilinmiyor";
    
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: ExpansionTile(
        leading: CircleAvatar(
          backgroundColor: app.isDone ? Colors.grey.shade200 : Colors.blue.shade50,
          child: Icon(_getCategoryIcon(app.category), color: app.isDone ? Colors.grey : Colors.blueAccent),
        ),
        title: Text(app.title, style: TextStyle(
          fontWeight: FontWeight.bold,
          decoration: app.isDone ? TextDecoration.lineThrough : null,
          color: app.isDone ? Colors.grey : Theme.of(context).textTheme.bodyLarge?.color,
        )),
        subtitle: Text("$petName - ${app.dateTime.day}.${app.dateTime.month}.${app.dateTime.year} ${app.dateTime.hour}:${app.dateTime.minute.toString().padLeft(2, '0')}"),
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (app.location != null && app.location!.isNotEmpty)
                  _buildDetailRow(Icons.location_on_outlined, "Konum: ${app.location}"),
                if (app.cost != null)
                  _buildDetailRow(Icons.payments_outlined, "Maliyet: ${app.cost} ₺"),
                if (app.description != null && app.description!.isNotEmpty)
                  _buildDetailRow(Icons.notes, app.description!),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    TextButton.icon(
                      onPressed: () => _deleteAppointment(app.id!),
                      icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                      label: const Text("Sil", style: TextStyle(color: Colors.redAccent)),
                    ),
                    const SizedBox(width: 8),
                    ElevatedButton.icon(
                      onPressed: () => _toggleStatus(app),
                      icon: Icon(app.isDone ? Icons.undo : Icons.check),
                      label: Text(app.isDone ? "Geri Al" : "Tamamla"),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: app.isDone ? Colors.grey : Colors.green,
                        foregroundColor: Colors.white,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(IconData icon, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(
        children: [
          Icon(icon, size: 16, color: Theme.of(context).hintColor),
          const SizedBox(width: 8),
          Expanded(child: Text(text, style: TextStyle(color: Theme.of(context).textTheme.bodyMedium?.color))),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.calendar_month_outlined, size: 80, color: Colors.grey.shade300),
          const SizedBox(height: 16),
          const Text("Henüz randevu yok.", style: TextStyle(fontSize: 18, color: Colors.grey, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text("Yeni bir randevu eklemek için + butonuna basın.", textAlign: TextAlign.center, style: TextStyle(color: Colors.grey)),
        ],
      ),
    );
  }
}
