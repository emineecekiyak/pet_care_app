import 'dart:async';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:mobil1/models/pet.dart';
import 'package:mobil1/models/vaccine.dart';
import 'package:mobil1/models/appointment.dart';

class PetDatabase {
  static final PetDatabase instance = PetDatabase._internal();
  static Database? _db;

  PetDatabase._internal();

  Future<Database> get database async {
    if (_db != null) return _db!;
    _db = await _initDb();
    return _db!;
  }

  Future<Database> _initDb() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'pets.db');

    return openDatabase(
      path,
      version: 4, 
      onCreate: (db, version) async {
        await _createPetsTable(db);
        await _createVaccinesTable(db);
        await _createAppointmentsTable(db);
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        if (oldVersion < 2) {
          await _createVaccinesTable(db);
        }
        if (oldVersion < 3) {
          await db.execute('ALTER TABLE vaccines ADD COLUMN frequencyMonths INTEGER');
        }
        if (oldVersion < 4) {
          await _createAppointmentsTable(db);
        }
      },
    );
  }

  Future<void> _createPetsTable(Database db) async {
    await db.execute('''
CREATE TABLE pets(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  age INTEGER NOT NULL,
  weight TEXT NOT NULL,
  breed TEXT NOT NULL,
  imagePath TEXT,
  birthDate TEXT,
  gender TEXT,
  neutered INTEGER
)
''');
  }

  Future<void> _createVaccinesTable(Database db) async {
    await db.execute('''
CREATE TABLE vaccines(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  petId INTEGER NOT NULL,
  name TEXT NOT NULL,
  date TEXT NOT NULL,
  isDone INTEGER NOT NULL,
  note TEXT,
  frequencyMonths INTEGER,
  FOREIGN KEY (petId) REFERENCES pets (id) ON DELETE CASCADE
)
''');
  }

  Future<void> _createAppointmentsTable(Database db) async {
    await db.execute('''
CREATE TABLE appointments(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  petId INTEGER NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  dateTime TEXT NOT NULL,
  category TEXT NOT NULL,
  location TEXT,
  cost REAL,
  isDone INTEGER NOT NULL,
  FOREIGN KEY (petId) REFERENCES pets (id) ON DELETE CASCADE
)
''');
  }

  // --- PET METHODS ---

  Future<List<Pet>> getAllPets() async {
    final db = await database;
    final result = await db.query('pets', orderBy: 'id DESC');
    return result
        .map(
          (row) => Pet(
            id: row['id'] as int?,
            name: row['name'] as String,
            type: row['type'] as String,
            age: row['age'] as int,
            weight: row['weight'] as String,
            breed: row['breed'] as String,
            imagePath: row['imagePath'] as String?,
            birthDate: row['birthDate'] != null
                ? DateTime.parse(row['birthDate'] as String)
                : null,
            gender: row['gender'] as String?,
            neutered: row['neutered'] != null
                ? (row['neutered'] as int) == 1
                : null,
          ),
        )
        .toList();
  }

  Future<int> insertPet(Pet pet) async {
    final db = await database;
    return db.insert('pets', {
      'name': pet.name,
      'type': pet.type,
      'age': pet.age,
      'weight': pet.weight,
      'breed': pet.breed,
      'imagePath': pet.imagePath,
      'birthDate': pet.birthDate?.toIso8601String(),
      'gender': pet.gender,
      'neutered': pet.neutered == null
          ? null
          : (pet.neutered! ? 1 : 0),
    });
  }

  Future<int> updatePet(Pet pet) async {
    if (pet.id == null) {
      throw ArgumentError('Pet id null, cannot update');
    }
    final db = await database;
    return db.update(
      'pets',
      {
        'name': pet.name,
        'type': pet.type,
        'age': pet.age,
        'weight': pet.weight,
        'breed': pet.breed,
        'imagePath': pet.imagePath,
        'birthDate': pet.birthDate?.toIso8601String(),
        'gender': pet.gender,
        'neutered': pet.neutered == null
            ? null
            : (pet.neutered! ? 1 : 0),
      },
      where: 'id = ?',
      whereArgs: [pet.id],
    );
  }

  Future<int> deletePet(int id) async {
    final db = await database;
    await db.delete('vaccines', where: 'petId = ?', whereArgs: [id]);
    await db.delete('appointments', where: 'petId = ?', whereArgs: [id]);
    return db.delete('pets', where: 'id = ?', whereArgs: [id]);
  }

  // --- VACCINE METHODS ---

  Future<List<Vaccine>> getVaccinesForPet(int petId) async {
    final db = await database;
    final result = await db.query(
      'vaccines',
      where: 'petId = ?',
      whereArgs: [petId],
      orderBy: 'date ASC',
    );
    return result.map((row) => Vaccine.fromMap(row)).toList();
  }

  Future<int> insertVaccine(Vaccine vaccine) async {
    final db = await database;
    return db.insert('vaccines', vaccine.toMap());
  }

  Future<int> updateVaccine(Vaccine vaccine) async {
    final db = await database;
    return db.update(
      'vaccines',
      vaccine.toMap(),
      where: 'id = ?',
      whereArgs: [vaccine.id],
    );
  }

  Future<int> deleteVaccine(int id) async {
    final db = await database;
    return db.delete('vaccines', where: 'id = ?', whereArgs: [id]);
  }

  // --- APPOINTMENT METHODS ---

  Future<List<Appointment>> getAllAppointments() async {
    final db = await database;
    final result = await db.query('appointments', orderBy: 'dateTime ASC');
    return result.map((row) => Appointment.fromMap(row)).toList();
  }

  Future<List<Appointment>> getAppointmentsForPet(int petId) async {
    final db = await database;
    final result = await db.query(
      'appointments',
      where: 'petId = ?',
      whereArgs: [petId],
      orderBy: 'dateTime ASC',
    );
    return result.map((row) => Appointment.fromMap(row)).toList();
  }

  Future<int> insertAppointment(Appointment appointment) async {
    final db = await database;
    return db.insert('appointments', appointment.toMap());
  }

  Future<int> updateAppointment(Appointment appointment) async {
    final db = await database;
    return db.update(
      'appointments',
      appointment.toMap(),
      where: 'id = ?',
      whereArgs: [appointment.id],
    );
  }

  Future<int> deleteAppointment(int id) async {
    final db = await database;
    return db.delete('appointments', where: 'id = ?', whereArgs: [id]);
  }
}
