class Vaccine {
  final int? id;
  final int petId;
  final String name;
  final DateTime date;
  final bool isDone;
  final String? note;
  final int? frequencyMonths; // 🆕 Tekrar sıklığı (ay bazında)

  Vaccine({
    this.id,
    required this.petId,
    required this.name,
    required this.date,
    this.isDone = false,
    this.note,
    this.frequencyMonths,
  });

  Vaccine copyWith({
    int? id,
    int? petId,
    String? name,
    DateTime? date,
    bool? isDone,
    String? note,
    int? frequencyMonths,
  }) {
    return Vaccine(
      id: id ?? this.id,
      petId: petId ?? this.petId,
      name: name ?? this.name,
      date: date ?? this.date,
      isDone: isDone ?? this.isDone,
      note: note ?? this.note,
      frequencyMonths: frequencyMonths ?? this.frequencyMonths,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'petId': petId,
      'name': name,
      'date': date.toIso8601String(),
      'isDone': isDone ? 1 : 0,
      'note': note,
      'frequencyMonths': frequencyMonths,
    };
  }

  factory Vaccine.fromMap(Map<String, dynamic> map) {
    return Vaccine(
      id: map['id'],
      petId: map['petId'],
      name: map['name'],
      date: DateTime.parse(map['date']),
      isDone: map['isDone'] == 1,
      note: map['note'],
      frequencyMonths: map['frequencyMonths'],
    );
  }
}
