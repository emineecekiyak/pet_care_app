class Appointment {
  final int? id;
  final int petId;
  final String title;
  final String? description;
  final DateTime dateTime;
  final String category; // Veteriner, Bakım, Eğitim, Diğer
  final String? location;
  final double? cost;
  final bool isDone;

  Appointment({
    this.id,
    required this.petId,
    required this.title,
    this.description,
    required this.dateTime,
    required this.category,
    this.location,
    this.cost,
    this.isDone = false,
  });

  Appointment copyWith({
    int? id,
    int? petId,
    String? title,
    String? description,
    DateTime? dateTime,
    String? category,
    String? location,
    double? cost,
    bool? isDone,
  }) {
    return Appointment(
      id: id ?? this.id,
      petId: petId ?? this.petId,
      title: title ?? this.title,
      description: description ?? this.description,
      dateTime: dateTime ?? this.dateTime,
      category: category ?? this.category,
      location: location ?? this.location,
      cost: cost ?? this.cost,
      isDone: isDone ?? this.isDone,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'petId': petId,
      'title': title,
      'description': description,
      'dateTime': dateTime.toIso8601String(),
      'category': category,
      'location': location,
      'cost': cost,
      'isDone': isDone ? 1 : 0,
    };
  }

  factory Appointment.fromMap(Map<String, dynamic> map) {
    return Appointment(
      id: map['id'],
      petId: map['petId'],
      title: map['title'],
      description: map['description'],
      dateTime: DateTime.parse(map['dateTime']),
      category: map['category'],
      location: map['location'],
      cost: map['cost']?.toDouble(),
      isDone: map['isDone'] == 1,
    );
  }
}
