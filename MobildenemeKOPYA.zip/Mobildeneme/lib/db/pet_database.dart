import 'dart:async';

import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

import '../models/pet.dart';

class PetDatabase {
  static final PetDatabase instance = PetDatabase._internal();
  static Database? _db;

  PetDatabase._internal();

  Future<Database> get database async {
    if (_db != null) return _db!;
    _db = await _initDb();
    return _db!;
  }

  Future<Database> _initDb() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'pets.db');

    return openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
CREATE TABLE pets(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  age INTEGER NOT NULL,
  weight TEXT NOT NULL,
  breed TEXT NOT NULL,
  imagePath TEXT,
  birthDate TEXT,
  gender TEXT,
  neutered INTEGER
)
''');
      },
    );
  }

  Future<List<Pet>> getAllPets() async {
    final db = await database;
    final result = await db.query('pets', orderBy: 'id DESC');
    return result
        .map(
          (row) => Pet(
            id: row['id'] as int?,
            name: row['name'] as String,
            type: row['type'] as String,
            age: row['age'] as int,
            weight: row['weight'] as String,
            breed: row['breed'] as String,
            imagePath: row['imagePath'] as String?,
            birthDate: row['birthDate'] != null
                ? DateTime.parse(row['birthDate'] as String)
                : null,
            gender: row['gender'] as String?,
            neutered: row['neutered'] != null
                ? (row['neutered'] as int) == 1
                : null,
          ),
        )
        .toList();
  }

  Future<int> insertPet(Pet pet) async {
    final db = await database;
    return db.insert('pets', {
      'name': pet.name,
      'type': pet.type,
      'age': pet.age,
      'weight': pet.weight,
      'breed': pet.breed,
      'imagePath': pet.imagePath,
      'birthDate': pet.birthDate?.toIso8601String(),
      'gender': pet.gender,
      'neutered': pet.neutered == null
          ? null
          : (pet.neutered! ? 1 : 0),
    });
  }

  Future<int> updatePet(Pet pet) async {
    if (pet.id == null) {
      throw ArgumentError('Pet id null, cannot update');
    }
    final db = await database;
    return db.update(
      'pets',
      {
        'name': pet.name,
        'type': pet.type,
        'age': pet.age,
        'weight': pet.weight,
        'breed': pet.breed,
        'imagePath': pet.imagePath,
        'birthDate': pet.birthDate?.toIso8601String(),
        'gender': pet.gender,
        'neutered': pet.neutered == null
            ? null
            : (pet.neutered! ? 1 : 0),
      },
      where: 'id = ?',
      whereArgs: [pet.id],
    );
  }

  Future<int> deletePet(int id) async {
    final db = await database;
    return db.delete('pets', where: 'id = ?', whereArgs: [id]);
  }
}


