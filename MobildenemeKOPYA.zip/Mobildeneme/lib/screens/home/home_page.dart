import 'package:flutter/material.dart';

import '../profile/pet_list_page.dart';
import '../../models/pet.dart';
import '../../db/pet_database.dart';
import '../food_tracker/food_tracker_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int selectedIndex = 0;

  final List<Pet> pets = [];

  @override
  void initState() {
    super.initState();
    _loadPets(); // 📥 uygulama açılırken DB'den yükle
  }

  Future<void> _loadPets() async {
    try {
      final items = await PetDatabase.instance.getAllPets();
      setState(() {
        pets
          ..clear()
          ..addAll(items);
      });
    } catch (e) {
      _showError("Veritabanı okunamadı: $e");
    }
  }

  Future<void> _addPet(Pet pet) async {
    try {
      final id = await PetDatabase.instance.insertPet(pet);
      final saved = pet.copyWith(id: id);
      setState(() {
        pets.insert(0, saved);
      });
      // DB'den tazele (güvenli senkron)
      await _loadPets();
    } catch (e) {
      _showError("Kaydedilemedi: $e");
    }
  }

  Future<void> _updatePet(int index, Pet pet) async {
    try {
      final currentId = pets[index].id;
      final toSave = pet.copyWith(id: currentId);
      await PetDatabase.instance.updatePet(toSave);
      setState(() {
        pets[index] = toSave;
      });
      await _loadPets();
    } catch (e) {
      _showError("Güncellenemedi: $e");
    }
  }

  Future<void> _deletePet(int index) async {
    try {
      final pet = pets[index];
      if (pet.id != null) {
        await PetDatabase.instance.deletePet(pet.id!);
      }
      setState(() {
        pets.removeAt(index);
      });
      await _loadPets();
    } catch (e) {
      _showError("Silinemedi: $e");
    }
  }

  void _showError(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      PetListPage(
        pets: pets,
        onAdd: _addPet,
        onUpdate: _updatePet,
        onDelete: _deletePet,
      ),
      FoodTrackerPage(pets: pets),
      const Center(child: Text("💉 Aşı Takvimi")),
      const Center(child: Text("📅 Randevular")),
      const Center(child: Text("⚙ Ayarlar")),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text("Pet Care"),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadPets,
            tooltip: "Verileri yenile",
          ),
        ],
      ),
      body: pages[selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: selectedIndex,
        onTap: (index) {
          setState(() => selectedIndex = index);
        },
        type: BottomNavigationBarType.fixed,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.pets), label: "Profil"),
          BottomNavigationBarItem(icon: Icon(Icons.restaurant), label: "Mama"),
          BottomNavigationBarItem(icon: Icon(Icons.vaccines), label: "Aşı"),
          BottomNavigationBarItem(icon: Icon(Icons.calendar_today), label: "Randevu"),
          BottomNavigationBarItem(icon: Icon(Icons.settings), label: "Ayarlar"),
        ],
      ),
    );
  }
}
