import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../models/food_entry.dart';
import '../../models/pet.dart';

class FoodTrackerPage extends StatefulWidget {
  final List<Pet> pets;

  const FoodTrackerPage({
    super.key,
    required this.pets,
  });

  @override
  State<FoodTrackerPage> createState() => _FoodTrackerPageState();
}

class _FoodTrackerPageState extends State<FoodTrackerPage> {
  final List<FoodEntry> _entries = [];

  @override
  void initState() {
    super.initState();
    _loadEntries();
  }

  Future<void> _loadEntries() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('food_entries');
    if (raw == null) return;

    final List decoded = jsonDecode(raw);
    setState(() {
      _entries
        ..clear()
        ..addAll(
          decoded.map((e) => FoodEntry.fromJson(e as Map<String, dynamic>)),
        );
    });
  }

  Future<void> _saveEntries() async {
    final prefs = await SharedPreferences.getInstance();
    final data =
        jsonEncode(_entries.map((e) => e.toJson()).toList(growable: false));
    await prefs.setString('food_entries', data);
  }

  Future<void> _openAddDialog() async {
    final foodCtrl = TextEditingController();
    final amountCtrl = TextEditingController();

    if (widget.pets.isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Önce en az bir hayvan eklemelisin.")),
      );
      return;
    }

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) {
        Pet selectedPet = widget.pets.first;

        return Padding(
          padding: EdgeInsets.only(
            left: 16,
            right: 16,
            top: 16,
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 16,
          ),
          child: StatefulBuilder(
            builder: (context, setModalState) {
              return Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Mama Kaydı Ekle",
                    style: Theme.of(ctx)
                        .textTheme
                        .titleMedium
                        ?.copyWith(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<Pet>(
                    value: selectedPet,
                    decoration: const InputDecoration(
                      labelText: "Hayvan",
                      border: OutlineInputBorder(),
                    ),
                    items: widget.pets
                        .map(
                          (p) => DropdownMenuItem(
                            value: p,
                            child: Text(p.name),
                          ),
                        )
                        .toList(),
                    onChanged: (value) {
                      if (value == null) return;
                      setModalState(() {
                        selectedPet = value;
                      });
                    },
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: foodCtrl,
                    decoration: const InputDecoration(
                      labelText: "Mama türü (örn. kuru mama)",
                      border: OutlineInputBorder(),
                    ),
                    textCapitalization: TextCapitalization.sentences,
                    textInputAction: TextInputAction.next,
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: amountCtrl,
                    decoration: const InputDecoration(
                      labelText: "Miktar (gram)",
                      border: OutlineInputBorder(),
                    ),
                    keyboardType: TextInputType.number,
                    textInputAction: TextInputAction.done,
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        final amount = int.tryParse(amountCtrl.text) ?? 0;
                        if (foodCtrl.text.trim().isEmpty || amount <= 0) {
                          Navigator.pop(ctx);
                          return;
                        }

                        final entry = FoodEntry(
                          petId: selectedPet.id,
                          petName: selectedPet.name,
                          foodType: foodCtrl.text.trim(),
                          amountGrams: amount,
                          time: DateTime.now(),
                        );

                        setState(() {
                          _entries.insert(0, entry);
                        });
                        _saveEntries();
                        Navigator.pop(ctx);
                      },
                      child: const Text("Kaydet"),
                    ),
                  ),
                ],
              );
            },
          ),
        );
      },
    );
  }

  String _formatTime(DateTime time) {
    final date =
        "${time.day.toString().padLeft(2, '0')}.${time.month.toString().padLeft(2, '0')}.${time.year}";
    final hour =
        "${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}";
    return "$date • $hour";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: _openAddDialog,
        child: const Icon(Icons.add),
      ),
      body: _entries.isEmpty
          ? const Center(
              child: Text(
                "Henüz mama kaydı yok 🥣",
                style: TextStyle(fontSize: 16),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.only(bottom: 80),
              itemCount: _entries.length,
              itemBuilder: (context, index) {
                final e = _entries[index];
                return Card(
                  margin:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: ListTile(
                    leading: const Icon(Icons.restaurant),
                    title: Text(
                      "${e.petName} • ${e.foodType}",
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    subtitle: Text(
                      "${e.amountGrams} gr\n${_formatTime(e.time)}",
                    ),
                    isThreeLine: true,
                    trailing: IconButton(
                      icon: const Icon(Icons.delete),
                      onPressed: () {
                        setState(() {
                          _entries.removeAt(index);
                        });
                        _saveEntries();
                      },
                    ),
                  ),
                );
              },
            ),
    );
  }
}


