class FoodEntry {
  final int? petId;
  final String petName;
  final String foodType;
  final int amountGrams;
  final DateTime time;

  FoodEntry({
    this.petId,
    required this.petName,
    required this.foodType,
    required this.amountGrams,
    required this.time,
  });

  Map<String, dynamic> toJson() => {
        'petId': petId,
        'petName': petName,
        'foodType': foodType,
        'amountGrams': amountGrams,
        'time': time.toIso8601String(),
      };

  factory FoodEntry.fromJson(Map<String, dynamic> json) => FoodEntry(
        petId: json['petId'],
        petName: json['petName'] ?? '',
        foodType: json['foodType'] ?? '',
        amountGrams: json['amountGrams'] ?? 0,
        time: DateTime.parse(json['time'] as String),
      );
}


