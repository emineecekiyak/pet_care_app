import 'dart:io';
import 'package:flutter/material.dart';
import 'package:mobil1/services/database_service.dart';
import 'package:mobil1/models/pet.dart';
import 'profile_edit_page.dart';

class ProfileViewPage extends StatelessWidget {
  final Pet pet;

  const ProfileViewPage({
    super.key,
    required this.pet,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(pet.name)),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // 🖼 PROFİL FOTO
            Center(
              child: CircleAvatar(
                radius: 70,
                backgroundColor: Colors.grey.shade300,
                backgroundImage: _getPetImage(pet),
                child: _getPetImage(pet) == null
                    ? const Icon(Icons.pets, size: 45)
                    : null,
              ),
            ),

            const SizedBox(height: 20),

            Text(
              pet.name,
              style: const TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              pet.type,
              style: const TextStyle(
                color: Colors.grey,
                fontSize: 16,
              ),
            ),

            const SizedBox(height: 28),

            _info(Icons.cake, "Yaş", pet.age.toString()),
            _info(Icons.monitor_weight, "Kilo", pet.weight),
            _info(Icons.pets, "Cins", pet.breed),

            const SizedBox(height: 28),

            // ✏️ DÜZENLE
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                icon: const Icon(Icons.edit),
                label: const Text("Profili Düzenle"),
                onPressed: () {
                   Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ProfileEditPage(pet: pet),
                    ),
                  ).then((_) {
                    // Sayfa geri döndüğünde verileri güncellemek gerekebilir
                    // Şimdilik basitçe bu sayfayı da kapatıyoruz ki listeden taze veriyle tekrar açılsın
                    Navigator.pop(context); 
                  });
                },
              ),
            ),

            const SizedBox(height: 12),

            // 🗑 SİL
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                icon: const Icon(Icons.delete),
                label: const Text("Hayvanı Sil"),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red,
                ),
                onPressed: () => _confirmDelete(context),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _info(IconData icon, String title, String value) {
    return Card(
      child: ListTile(
        leading: Icon(icon),
        title: Text(title),
        trailing: Text(value),
      ),
    );
  }

  void _confirmDelete(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Emin misiniz?"),
        content: const Text("Bu hayvan silinecek."),
        actions: [
          TextButton(
            child: const Text("İptal"),
            onPressed: () => Navigator.pop(context),
          ),
          TextButton(
            child: const Text(
              "Sil",
              style: TextStyle(color: Colors.red),
            ),
            onPressed: () async {
              Navigator.pop(context); // Dialog kapat
              if (pet.id != null) {
                await DatabaseService().deletePet(pet.id!);
              }
              if (context.mounted) {
                Navigator.pop(context); // Sayfayı kapat
              }
            },
          ),
        ],
      ),
    );
  }

  /// 🖼 FOTO / AVATAR KARARI
  ImageProvider? _getPetImage(Pet pet) {
    if (pet.imagePath != null && pet.imagePath!.isNotEmpty) {
      try {
        final file = File(pet.imagePath!);
        if (file.existsSync()) {
          return FileImage(file);
        }
      } catch (e) {
        // Dosya okuma hatası, asset'e geç
      }
    }

    if (pet.type == "Kedi") {
      return const AssetImage('assets/images/avatars/cat.png');
    }

    if (pet.type == "Köpek") {
      return const AssetImage('assets/images/avatars/dog.png');
    }

    // fallback (ileride başka tür eklenirse)
    return const AssetImage('assets/images/avatars/cat.png');
  }
}
