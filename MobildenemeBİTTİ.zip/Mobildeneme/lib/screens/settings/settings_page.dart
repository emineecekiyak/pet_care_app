import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:mobil1/services/auth_service.dart';
import 'package:mobil1/services/database_service.dart';
import '../../theme_notifier.dart'; 

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  String _userName = "";
  String _userAvatar = "👤";
  bool _isDarkMode = false;
  final DatabaseService _db = DatabaseService();

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _userName = prefs.getString('user_name') ?? "Kullanıcı";
      _userAvatar = prefs.getString('user_avatar') ?? "👤";
      _isDarkMode = prefs.getBool('is_dark_mode') ?? false;
    });
  }

  Future<void> _updateName() async {
    final controller = TextEditingController(text: _userName);
    final newName = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("İsim Düzenle"),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(labelText: "Adınız"),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text("İptal")),
          ElevatedButton(onPressed: () => Navigator.pop(ctx, controller.text), child: const Text("Kaydet")),
        ],
      ),
    );

    if (newName != null && newName.isNotEmpty) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('user_name', newName);
      setState(() => _userName = newName);
    }
  }

  Future<void> _updateAvatar() async {
    final avatars = ["👤", "🐱", "🐶", "🐰", "🦊", "🐯", "🦁", "🐢"];
    final newAvatar = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("Avatar Seç"),
        content: Wrap(
          spacing: 10,
          children: avatars.map((a) => InkWell(
            onTap: () => Navigator.pop(ctx, a),
            child: CircleAvatar(
              backgroundColor: _userAvatar == a ? Colors.blue.shade100 : Colors.grey.shade100,
              child: Text(a, style: const TextStyle(fontSize: 24)),
            ),
          )).toList(),
        ),
      ),
    );

    if (newAvatar != null) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('user_avatar', newAvatar);
      setState(() => _userAvatar = newAvatar);
    }
  }

  Future<void> _toggleDarkMode(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('is_dark_mode', value);
    setState(() => _isDarkMode = value);
    themeNotifier.value = value ? ThemeMode.dark : ThemeMode.light;
  }

  Future<void> _resetData() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("Verileri Sıfırla?"),
        content: const Text("Tüm hayvan kayıtları, aşılar ve randevular silinecek. Bu işlem geri alınamaz!"),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text("İptal")),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text("Sıfırla", style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (confirm == true) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Siliniyor... Lütfen bekleyin.")));
      }
      
      try {
        // 1. Clear Local Prefs
        final prefs = await SharedPreferences.getInstance();
        await prefs.clear();

        // 2. Clear Firestore Data (Iterative approach)
        
        // Delete Pets
        final pets = await _db.getPets().first; 
        for (var p in pets) {
          if (p.id != null) await _db.deletePet(p.id!);
        }

        // Delete Vaccines (Global list)
        final vaccines = await _db.getAllVaccines().first;
        for (var v in vaccines) {
          if (v.id != null) await _db.deleteVaccine(v.id!);
        }
        
        // Delete Appointments (Global list)
        final appointments = await _db.getAllAppointments().first;
        for (var a in appointments) {
          if (a.id != null) await _db.deleteAppointment(a.id!);
        }

        // Delete Food Entries
        final food = await _db.getFoodEntries().first;
        for (var f in food) {
          if (f.id != null) await _db.deleteFoodEntry(f.id!);
        }

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Tüm veriler başarıyla silindi.")));
          Navigator.of(context).popUntil((route) => route.isFirst);
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Hata oluştu: $e")));
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: ListView(
        children: [
          const SizedBox(height: 20),
          // Profile Section
          Center(
            child: Column(
              children: [
                Stack(
                  children: [
                    CircleAvatar(
                      radius: 50,
                      backgroundColor: Colors.blue.shade50,
                      child: Text(_userAvatar, style: const TextStyle(fontSize: 50)),
                    ),
                    Positioned(
                      bottom: 0,
                      right: 0,
                      child: GestureDetector(
                        onTap: _updateAvatar,
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: const BoxDecoration(color: Colors.blueAccent, shape: BoxShape.circle),
                          child: const Icon(Icons.camera_alt, color: Colors.white, size: 20),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(_userName, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                    IconButton(onPressed: _updateName, icon: const Icon(Icons.edit_outlined, size: 20)),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 32),
          
          _buildSectionHeader("Görünüm"),
          SwitchListTile(
            title: const Text("Karanlık Mod"),
            subtitle: const Text("Gözlerinizi yormayan koyu tema"),
            secondary: const Icon(Icons.dark_mode_outlined),
            value: _isDarkMode,
            onChanged: _toggleDarkMode,
          ),
          
          const SizedBox(height: 16),
          _buildSectionHeader("Hesap"),
          ListTile(
            leading: const Icon(Icons.email_outlined),
            title: const Text("E-posta"),
            subtitle: Text(FirebaseAuth.instance.currentUser?.email ?? "Giriş yapılmamış"),
          ),
          ListTile(
            leading: const Icon(Icons.logout, color: Colors.orange),
            title: const Text("Çıkış Yap"),
            subtitle: const Text("Hesabınızdan çıkış yapın"),
            onTap: () async {
              final confirm = await showDialog<bool>(
                context: context,
                builder: (ctx) => AlertDialog(
                  title: const Text("Çıkış Yap?"),
                  content: const Text("Hesabınızdan çıkış yapmak istediğinize emin misiniz?"),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(ctx),
                      child: const Text("İptal"),
                    ),
                    ElevatedButton(
                      onPressed: () => Navigator.pop(ctx, true),
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
                      child: const Text("Çıkış Yap"),
                    ),
                  ],
                ),
              );

              if (confirm == true) {
                await AuthService().signOut();
              }
            },
          ),
          
          const SizedBox(height: 16),
          _buildSectionHeader("Veri Yönetimi"),
          ListTile(
            leading: const Icon(Icons.delete_forever, color: Colors.redAccent),
            title: const Text("Tüm Verileri Sıfırla", style: TextStyle(color: Colors.redAccent)),
            subtitle: const Text("Kayıtlı her şeyi siler"),
            onTap: _resetData,
          ),
          
          const SizedBox(height: 16),
          _buildSectionHeader("Hakkında"),
          const ListTile(
            leading: Icon(Icons.info_outline),
            title: Text("Uygulama Sürümü"),
            subtitle: Text("1.2.0"),
          ),
          const ListTile(
            leading: Icon(Icons.favorite_border, color: Colors.pink),
            title: Text("Pet Care App"),
            subtitle: Text("Dostlarınız için sevgiyle yapıldı."),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Text(
        title.toUpperCase(),
        style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.grey.shade600, letterSpacing: 1.2),
      ),
    );
  }
}
